// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.6/firebase-app.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import {
  getFirestore,
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  updateDoc,
} from "https://www.gstatic.com/firebasejs/9.6.6/firebase-firestore.js";


 const firebaseConfig = {
   apiKey: "AIzaSyDOcPqL7Ug8xIQpQCIxr-yt0VnHFVUmEdg",
   authDomain: "portafolio-79a19.firebaseapp.com",
   projectId: "portafolio-79a19",
   storageBucket: "portafolio-79a19.appspot.com",
   messagingSenderId: "100789370450",
   appId: "1:100789370450:web:95ecb2974a14173ea7e98b"
 };
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore();// conexion a la BD
export {
  db,
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  updateDoc,
};
